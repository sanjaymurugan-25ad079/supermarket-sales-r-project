# app.R
# Supermarket Sales Analysis - Shiny App

library(shiny)
library(ggplot2)

ui <- fluidPage(
  titlePanel("Supermarket Sales Analysis"),

  sidebarLayout(
    sidebarPanel(
      fileInput("file", "Upload Sales CSV", accept = ".csv"),
      selectInput("category", "Select Category",
                  choices = "All"),
      br(),
      helpText("The app demonstrates CSV reading, data frames, frequency tables, factors, mathematical operations, and data filtering.")
    ),

    mainPanel(
      tabsetPanel(
        tabPanel("Dashboard",
                 br(),
                 fluidRow(
                   column(3, wellPanel(h4("Total Sales"), textOutput("totalSales"))),
                   column(3, wellPanel(h4("Average Sales"), textOutput("avgSales"))),
                   column(3, wellPanel(h4("Total Quantity"), textOutput("totalQty"))),
                   column(3, wellPanel(h4("Top Product"), textOutput("topProduct")))
                 ),
                 h4("Sales Data"),
                 tableOutput("dataTable")
        ),
        tabPanel("Category Frequency",
                 br(),
                 tableOutput("frequencyTable"),
                 plotOutput("categoryPlot")
        ),
        tabPanel("Mathematical Analysis",
                 br(),
                 tableOutput("mathTable")
        ),
        tabPanel("Sales Chart",
                 br(),
                 plotOutput("salesPlot")
        )
      )
    )
  )
)

server <- function(input, output, session) {

  sales_data <- reactive({
    if (is.null(input$file)) {
      read.csv("sales.csv", stringsAsFactors = FALSE)
    } else {
      read.csv(input$file$datapath, stringsAsFactors = FALSE)
    }
  })

  observe({
    d <- sales_data()
    updateSelectInput(session, "category",
                      choices = c("All", sort(unique(d$Category))),
                      selected = "All")
  })

  filtered_data <- reactive({
    d <- sales_data()
    if (input$category == "All") d else d[d$Category == input$category, ]
  })

  output$totalSales <- renderText({
    paste0("Rs. ", format(sum(filtered_data()$Sales), big.mark = ","))
  })

  output$avgSales <- renderText({
    paste0("Rs. ", round(mean(filtered_data()$Sales), 2))
  })

  output$totalQty <- renderText({
    sum(filtered_data()$Quantity)
  })

  output$topProduct <- renderText({
    d <- filtered_data()
    totals <- aggregate(Sales ~ Product, d, sum)
    totals$Product[which.max(totals$Sales)]
  })

  output$dataTable <- renderTable({
    filtered_data()
  }, striped = TRUE, bordered = TRUE, hover = TRUE)

  output$frequencyTable <- renderTable({
    d <- sales_data()
    data.frame(
      Category = names(table(d$Category)),
      Frequency = as.integer(table(d$Category))
    )
  })

  output$categoryPlot <- renderPlot({
    d <- sales_data()
    freq <- as.data.frame(table(d$Category))
    ggplot(freq, aes(x = Var1, y = Freq)) +
      geom_col() +
      labs(title = "Category Frequency", x = "Category", y = "Frequency") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 30, hjust = 1))
  })

  output$mathTable <- renderTable({
    d <- filtered_data()
    data.frame(
      Product = d$Product,
      Sales = d$Sales,
      LogSales = round(log(d$Sales), 3),
      SqrtSales = round(sqrt(d$Sales), 3),
      RoundedSales = round(d$Sales, 1)
    )
  })

  output$salesPlot <- renderPlot({
    d <- filtered_data()
    ggplot(d, aes(x = reorder(Product, Sales), y = Sales)) +
      geom_col() +
      coord_flip() +
      labs(title = "Sales by Product", x = "Product", y = "Sales (Rs.)") +
      theme_minimal()
  })
}

shinyApp(ui = ui, server = server)
